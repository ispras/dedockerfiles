# Copyright (c) Facebook, Inc. and its affiliates.
from torch.utils.data.datapipes.utils.common import StreamWrapper

__all__ = ["StreamWrapper"]
