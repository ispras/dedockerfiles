__version__ = '0.3.0a0+fbf097d'
git_version = 'fbf097d43c9643fb9ca9ddcb7e2891630aac84ac'
